Rails.application.routes.draw do
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html

  root to: 'search#new'

  get 'search', action: :search_result, controller: 'search'
  get 'single_search', action: :single_search_result, controller: 'search'
  get 'ticker', action: :show, controller: 'tickers'

  get 'submit_stock_price', action: :new, controller: 'speed_layer'
  post 'submit_stock_price', action: :create, controller: 'speed_layer'

end
