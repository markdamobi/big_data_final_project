class NewsEngine
  # Might change to use ticker name instead of symbol if that's getting better hit.
  # assume input date is in this format: 2020-05-27
  # q = "googler -n 10 ABIO stock news after:2020-05-27 before:2020-05-29 --np" # alternate style.
  def self.get(ticker:, date:)
    formatted_date = Date.parse(date).strftime("%m/%d/%Y")
    query = "googler -n 10 --from #{formatted_date} --to #{formatted_date} #{ticker} stock news --np"

    result = _parse(`#{query}`)
  end

  private

  def self._parse(result)
    all_news = result.split("\n\n")

    all_news.map do |news_data|
      news_data = news_data.split("\n").map(&:squish)

      title, url, date, *snippet = news_data
      date = Date.parse(date) rescue date

      NewsObject.new(
        title: title,
        url: url,
        date: date,
        snippet: snippet.join(" ")
      )
    end
  end
end