class HbaseApiClient
  BASE_URL = "#{ENV['HBASE_API_HOST']}:#{ENV['HBASE_API_PORT']}"
  DATA_ENDPOINT = "api/data"
  SINGLE_DATA_ENDPOINT = "api/single_data"
  TICKER_INFO_ENDPOINT = "api/us_tickers"

  def self.get(date:)
    url = "http://#{BASE_URL}/#{DATA_ENDPOINT}"
    options = {
      query: { date: date }
    }

    resp = HTTParty.get(url, options)

    resp
  end

  def self.get_range(from_date:, ticker:, to_date:)
    url = "http://#{BASE_URL}/#{SINGLE_DATA_ENDPOINT}"
    options = {
      query: {
        from_date: from_date,
        ticker: ticker,
        to_date: to_date
      }
    }

    resp = HTTParty.get(url, options)

    resp
  end

  def self.get_ticker(ticker:)
    url = "http://#{BASE_URL}/#{TICKER_INFO_ENDPOINT}"
    options = {
      query: {
        ticker: ticker
      }
    }

    resp = HTTParty.get(url, options)

    resp
  end

  def self.get_us_tickers
    url = "http://#{BASE_URL}/#{TICKER_INFO_ENDPOINT}"
    resp = HTTParty.get(url)
    resp
  end

  private

  attr_reader :host, :port, :url
end