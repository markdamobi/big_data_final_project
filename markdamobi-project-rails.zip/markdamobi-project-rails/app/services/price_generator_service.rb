class PriceGeneratorService
  def self.generate(date:, batch_size: 1000)
    tickers = HbaseApiClient.get_us_tickers

    messages = tickers.map do |details|
      generate_payload(ticker: details["ticker"], name: details["name"], date: date)
    end

    total = 0

    messages.each_slice([batch_size, 1000].min) do |batch|
      KafkaService.deliver_multiple(messages: batch)
      total += batch.size

      puts "total delivered: #{total}..."
    end
  end

  def self.generate_payload(ticker:, name:, date:)
    open_price = rand(0.5..100)
    close_price = (100 + rand(-50..100)) * open_price / 100.0

    high_price = (100 + rand(1..100)) * [open_price, close_price].max / 100.0
    low_price = (100 + rand(-50..-5)) * [open_price, close_price].min / 100.0

    {
      ticker: ticker,
      date: date,
      open: open_price,
      close: close_price,
      high: high_price,
      low: low_price,
      volume: rand(10000..100000000),
      name: name
    }
  end
end