class KafkaService
  TOPIC = "markdamobi_stock_price_info"
  BROKERS = [
    "b-1.mpcs53014-kafka.fwx2ly.c4.kafka.us-east-2.amazonaws.com:9092",
    "b-2.mpcs53014-kafka.fwx2ly.c4.kafka.us-east-2.amazonaws.com:9092"
  ]

  def self.deliver(message:)
    kafka = Kafka.new(BROKERS, client_id: "markdamobi-project-rails")

    producer = kafka.producer

    producer.produce(message.to_json, topic: TOPIC)

    producer.deliver_messages
  end

  def self.deliver_multiple(messages:)
    kafka = Kafka.new(BROKERS, client_id: "markdamobi-project-rails")

    producer = kafka.producer

    messages.each do |message|
      producer.produce(message.to_json, topic: TOPIC)
    end

    producer.deliver_messages
  end
end