class NewsObject
    include ActiveModel::Model
    attr_reader :title, :url, :date, :snippet

  def initialize(title:, url:, date:, snippet:)
    @title = title
    @url = url
    @date = date
    @snippet = snippet
  end
end