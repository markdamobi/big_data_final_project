class HomeController < ApplicationController
  def index
    @data = JSON.parse(File.read(Rails.root.join('spec', 'response.json')))
    # raise StandardError.new("Date must be passed in to query params") unless params[:date].present?
    # @data = HbaseApiClient.get(date: params[:date])
  end
end
