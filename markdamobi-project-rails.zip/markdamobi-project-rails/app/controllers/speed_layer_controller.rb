class SpeedLayerController < ApplicationController
  def new
  end

  def create
    payload = {
      ticker: params[:ticker],
      date: params[:date],
      open: params[:open],
      close: params[:close],
      high: params[:high],
      low: params[:low],
      volume: params[:volume],
      name: HbaseApiClient.get_ticker(ticker: params[:ticker])["name"] || "N/A"
    }

    KafkaService.deliver(message: payload)

    redirect_to '/', flash: {success: "New Price for #{params[:ticker]} on #{params[:date]} successfully submitted." }
  end
end