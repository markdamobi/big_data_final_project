class SearchController < ApplicationController
  def new
  end

  def search_result
    date = params[:date]

    resp = HbaseApiClient.get(date: date)
    @data = JSON.parse(resp.response.body)

    @data.sort_by! do |row|
      [- Float(row["percent_change"]), row["ticker"]]
    end
  end

  def single_search_result
    from_date = params[:from_date]
    to_date = params[:to_date]
    ticker = params[:ticker]

    resp = HbaseApiClient.get_range(
      ticker: ticker,
      from_date: from_date,
      to_date: to_date || from_date
    )

    @data = JSON.parse(resp.response.body)
    @ticker = ticker

    @data.sort_by! do |row|
      [- Float(row["percent_change"]), row["effective_date"]]
    end
  end
end