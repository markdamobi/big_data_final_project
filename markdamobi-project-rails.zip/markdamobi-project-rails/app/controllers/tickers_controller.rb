class TickersController < ApplicationController
  def index

  end

  def show
    @ticker = params[:ticker]
    @date = params[:date]

    @news_objects = NewsEngine.get(ticker: @ticker, date: @date)
  end
end