'use strict';
var assert = require('assert');
var _ = require('underscore');
const express = require('express');
const app = express();
const hbase = require('hbase')
const port = Number(process.argv[2]);
const hbase_host = process.argv[3];
const hbase_port = Number(process.argv[4]);


const hclient = hbase({host: hbase_host, port: hbase_port});

function rowsToHash(rows) {
  var data = []
  var ticker_info = {}
  rows.forEach(function (row) {
    var ticker = row['key'].split(":")[2]

    if(_.isEmpty(ticker_info))
      ticker_info['ticker'] = ticker;

    if(ticker_info['ticker'] != ticker){
      data.push(ticker_info);
      ticker_info = {};
      ticker_info['ticker'] = ticker;
    }

    ticker_info[row['column'].split(":")[1]] = row['$']
  });

  if(!_.isEmpty(ticker_info))
    data.push(ticker_info);

  return data;
}

//for the api/single_data where every row will contain ticker.
function rowsToHashByDate(rows) {
  var data = []
  var ticker_info = {}
  rows.forEach(function (row) {
    var effective_date = row['key'].split(":")[1]

    if(_.isEmpty(ticker_info))
      ticker_info['effective_date'] = effective_date;

    if(ticker_info['effective_date'] != effective_date){
      data.push(ticker_info);
      ticker_info = {};
      ticker_info['effective_date'] = effective_date;
    }

    ticker_info[row['column'].split(":")[1]] = row['$']
  });

  if(!_.isEmpty(ticker_info))
    data.push(ticker_info);

  return data;
}

app.get('/api/data', (req, res) => {
  var effective_date = req.query.date; //e.g '2020-08-05'
  hclient.table('markdamobi_spikes_hbase').scan({
    filter: { type: 'PrefixFilter', value: effective_date }
  },
    (error, rows) => {
      var data = rowsToHash(rows);
      res.send(data);
    }
  )
});

app.get('/api/single_data', (req, res) => {
  var from_date = req.query.from_date;
  var to_date = req.query.to_date;
  var ticker = req.query.ticker;

  hclient.table('markdamobi_spikes_hbase_by_ticker').scan({ startRow: `${ticker}:${from_date}`, endRow: `${ticker}:${to_date}:zzzz`},
      (error, rows) => {

        var data = rowsToHashByDate(rows);
        res.send(data);
      }
  )
});

app.get('/api/us_tickers', (req, res) => {
  var ticker = req.query.ticker;

  if(!(ticker == undefined)){
    hclient.table('markdamobi_us_tickers_hbase').row(ticker).get("info:name",
        (error, rows) => {
          if(error && error['code'] == 404) //ticker doesn't exist in database.
            res.send({});
          else {
            var data = {ticker: ticker, name: rows[0]['$']};
            res.send(data);
          }
        }
    )
  }
  else {
    hclient.table('markdamobi_us_tickers_hbase').scan({batch: 25000},
        (error, rows) => {

          var data = [];
          rows.forEach(function (row) {
            data.push({ticker: row['key'], name: row['$']})
          });
          res.send(data);
        }
    )
  }
});



app.listen(port, () => console.log(`App is running on port ${port}`));
