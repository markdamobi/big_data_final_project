import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010._
import com.fasterxml.jackson.databind.{ DeserializationFeature, ObjectMapper }
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.TableName
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.ConnectionFactory
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes

//import java.text.SimpleDateFormat
//import java.util.Date

object StreamStockInfo {
  val mapper = new ObjectMapper()
  mapper.registerModule(DefaultScalaModule)
  val hbaseConf: Configuration = HBaseConfiguration.create()
  hbaseConf.set("hbase.zookeeper.property.clientPort", "2181")
  hbaseConf.set("hbase.zookeeper.quorum", "localhost")

  val hbaseConnection = ConnectionFactory.createConnection(hbaseConf)
  val table = hbaseConnection.getTable(TableName.valueOf("markdamobi_spikes_hbase"))
  val table_by_ticker = hbaseConnection.getTable(TableName.valueOf("markdamobi_spikes_hbase_by_ticker"))
//  val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
  
  def main(args: Array[String]) {
    if (args.length < 1) {
      System.err.println(s"""
        |Usage: StreamStockInfo <brokers>
        |  <brokers> is a list of one or more Kafka brokers
        | 
        """.stripMargin)
      System.exit(1)
    }

    val Array(brokers) = args

    // Create context with 2 second batch interval
    val sparkConf = new SparkConf().setAppName("StreamStockPrice")
    val ssc = new StreamingContext(sparkConf, Seconds(2))

    // Create direct kafka stream with brokers and topics
    val topicsSet = Set("markdamobi_stock_price_info")
    // Create direct kafka stream with brokers and topics
    val kafkaParams = Map[String, Object](
      "bootstrap.servers" -> brokers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "use_a_separate_group_id_for_each_stream",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
    val stream = KafkaUtils.createDirectStream[String, String](
      ssc, PreferConsistent,
      Subscribe[String, String](topicsSet, kafkaParams)
    )

    // Get the lines, split them into words, count the words and print
    val serializedRecords = stream.map(_.value);
    val reports = serializedRecords.map(rec => mapper.readValue(rec, classOf[StockInfo]))

    // How to write to an HBase table
    val batchStats = reports.map(sp => {
      val percent_change = ((sp.close.toDouble - sp.open.toDouble) / sp.open.toDouble) * 100
      val date_percent_ticker = sp.date + ":" + percent_change.toInt.toString + ":" + sp.ticker

      if (percent_change < -15 || percent_change > 15) {
        val put = new Put(Bytes.toBytes(date_percent_ticker))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("ticker"), Bytes.toBytes(sp.ticker))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("name"), Bytes.toBytes(sp.name))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("effective_date"), Bytes.toBytes(sp.date))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("open"), Bytes.toBytes(sp.open))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("close"), Bytes.toBytes(sp.close))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("percent_change"), Bytes.toBytes(percent_change.toString))
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("country"), Bytes.toBytes("USA"))
        table.put(put)

        val ticker_date_percent = sp.ticker + ":" + sp.date + ":" + percent_change.toInt.toString

        val put2 = new Put(Bytes.toBytes(ticker_date_percent))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("ticker"), Bytes.toBytes(sp.ticker))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("name"), Bytes.toBytes(sp.name))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("effective_date"), Bytes.toBytes(sp.date))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("open"), Bytes.toBytes(sp.open))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("close"), Bytes.toBytes(sp.close))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("percent_change"), Bytes.toBytes(percent_change.toString))
        put2.addColumn(Bytes.toBytes("info"), Bytes.toBytes("country"), Bytes.toBytes("USA"))
        table_by_ticker.put(put2)
      }


    })
    batchStats.print()
    
    // Start the computation
    ssc.start()
    ssc.awaitTermination()
  }

}
