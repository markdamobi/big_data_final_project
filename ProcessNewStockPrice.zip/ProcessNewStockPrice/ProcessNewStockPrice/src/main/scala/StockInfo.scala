import java.util.Date

case class StockInfo(
    ticker: String,
    name: String,
    date: String,
    open: String,
    close: String,
    high: String,
    low: String,
    volume: String,
    country: String)